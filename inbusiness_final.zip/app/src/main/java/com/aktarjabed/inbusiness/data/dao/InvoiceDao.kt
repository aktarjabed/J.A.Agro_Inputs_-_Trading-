package com.aktarjabed.inbusiness.data.dao

import androidx.room.*
import com.aktarjabed.inbusiness.data.entities.Invoice
import com.aktarjabed.inbusiness.data.entities.InvoiceItem
import com.aktarjabed.inbusiness.data.entities.InvoiceSequence
import kotlinx.coroutines.flow.Flow

@Dao
interface InvoiceDao {

    @Query("SELECT * FROM invoices WHERE businessId = :businessId ORDER BY createdAt DESC")
    fun getAllInvoices(businessId: String): Flow<List<Invoice>>

    @Query("SELECT * FROM invoices WHERE businessId = :businessId ORDER BY createdAt DESC")
    suspend fun getAllInvoicesOnce(businessId: String): List<Invoice>

    @Query("SELECT * FROM invoices WHERE id = :id AND businessId = :businessId LIMIT 1")
    suspend fun getInvoiceById(id: String, businessId: String): Invoice?

    @Query("SELECT * FROM invoices WHERE idempotencyKey = :idempotencyKey AND businessId = :businessId LIMIT 1")
    suspend fun getInvoiceByIdempotencyKey(idempotencyKey: String, businessId: String): Invoice?

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId AND invoiceId IN (SELECT id FROM invoices WHERE businessId = :businessId)")
    suspend fun getInvoiceItems(invoiceId: String, businessId: String): List<InvoiceItem>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertInvoice(invoice: Invoice)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: InvoiceItem)

    @Query("UPDATE invoices SET amountPaid = :amountPaid, balanceDue = :balanceDue, paymentMethod = :paymentMethod WHERE id = :invoiceId AND businessId = :businessId")
    suspend fun updateInvoicePayment(invoiceId: String, businessId: String, amountPaid: Double, balanceDue: Double, paymentMethod: String): Int

    @Query("DELETE FROM invoice_items WHERE invoiceId = :invoiceId AND invoiceId IN (SELECT id FROM invoices WHERE businessId = :businessId)")
    suspend fun deleteItemsForInvoice(invoiceId: String, businessId: String): Int

    @Query("DELETE FROM invoices WHERE id = :invoiceId AND businessId = :businessId")
    suspend fun deleteInvoice(invoiceId: String, businessId: String): Int

    @Query("SELECT * FROM invoices WHERE businessId = :businessId AND (invoiceNumber LIKE '%' || :query || '%' OR customerName LIKE '%' || :query || '%')")
    fun searchInvoices(businessId: String, query: String): Flow<List<Invoice>>

    @Query("SELECT * FROM invoices WHERE businessId = :businessId ORDER BY createdAt DESC LIMIT :limit")
    suspend fun getRecentInvoicesByBusiness(businessId: String, limit: Int): List<Invoice>

    @Query("SELECT * FROM invoice_sequence WHERE businessId = :businessId LIMIT 1")
    suspend fun getInvoiceSequence(businessId: String): InvoiceSequence?

    @Query("UPDATE invoice_sequence SET lastSequenceNumber = lastSequenceNumber + 1 WHERE businessId = :businessId")
    suspend fun incrementSequence(businessId: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSequence(sequence: InvoiceSequence): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSequence(sequence: InvoiceSequence)

    @Transaction
    suspend fun createInvoiceTransactionally(
        invoice: Invoice,
        items: List<InvoiceItem>,
        sequence: InvoiceSequence
    ) {
        insertInvoice(invoice)
        items.forEach { insertItem(it) }
        insertOrUpdateSequence(sequence)
    }
}
